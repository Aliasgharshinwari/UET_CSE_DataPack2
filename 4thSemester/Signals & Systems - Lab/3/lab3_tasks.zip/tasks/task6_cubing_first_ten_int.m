for i = 1:10
    cubes(i,1) = i.^3;
end
disp(cubes);