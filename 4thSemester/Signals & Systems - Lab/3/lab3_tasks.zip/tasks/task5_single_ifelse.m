x = 1;
y = 10;
z = 4;

if x < y & z < 5
    w = x*y*z;
end

w