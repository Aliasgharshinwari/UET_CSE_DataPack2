function sorted_array = bubble_sort(array)

n = length(array);
for i = 1:n-1
    for j = 1:n-i
        if array(j) > array(j+1)
            temp = array(j);
            array(j) = array(j+1);
            array(j+1) = temp;
        end
    end
end
sorted_array = array;
end
