function index = bin_search(array, value)

n = length(array);
low = 1;
high = n;
while low <= high
    mid = floor((low + high) / 2);
    if array(mid) == value
        index = mid;
        return
    elseif array(mid) < value
        low = mid + 1;
    else
        high = mid - 1;
    end
end
index = -1;
end