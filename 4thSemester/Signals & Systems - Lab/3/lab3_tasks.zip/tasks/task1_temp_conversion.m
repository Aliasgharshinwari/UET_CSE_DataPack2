function Tc = task1_temp_conversion(Tf)
Tc = (5/9)*(Tf - 32)
end