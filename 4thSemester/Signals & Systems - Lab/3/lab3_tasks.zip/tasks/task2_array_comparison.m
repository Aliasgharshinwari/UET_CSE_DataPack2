clc
clear

x=[-3,0,0,2,6,8];
y=[-5,-2,0,3,4,10];
result = x(x > y)