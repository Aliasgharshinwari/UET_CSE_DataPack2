# Flappy Spongy
A flappy bird like game with...

##	\*\*\* dRuMroLl \*\*\*
![spongebob dancing gif](assets/spongebob.gif)
## :yellow_heart: SpongeBob!! :yellow_heart:

Done as a project for OS course

using pygame library and multithreading.

<br>

Group project done by 
-
* __[Shreja R](https://github.com/shreja2000)__
* __[Shresta M](https://github.com/shresta-m)__
* __[Harish K M](https://github.com/HarishKMurali)__
* __[Santhosh Raghul](https://github.com/santhosh-raghul)__
