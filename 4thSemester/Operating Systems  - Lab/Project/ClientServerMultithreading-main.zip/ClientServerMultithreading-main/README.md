# ClientServerMultithreading
This is OS project for University subject which Includes server and client with multithreading and some functions.
