using UnityEngine;
using UnityEngine.UI;

public class CountdownTimer : MonoBehaviour
{
    public static CountdownTimer instance;
    public float timeLimit;
    public TMPro.TMP_Text timerText;
    private float timeRemaining;
    private bool timerIsRunning = false;

    private void Awake() {
        instance = this;
    }
    private void Start()
    {
        timeRemaining = timeLimit;
    }

    private void Update()
    {
        if (timerIsRunning)
        {
            if (timeRemaining > 0)
            {
                timeRemaining -= Time.deltaTime;
                //int hours = (int)(timeRemaining / 3600);
                int minutes = (int)((timeRemaining % 3600) / 60);
                int seconds = (int)(timeRemaining % 60);
                //timerText.text = string.Format("{0:00}:{1:00}:{2:00}", hours, minutes, seconds);
                timerText.text = "TIME LEFT = "+string.Format("{0:00}:{1:00}", minutes, seconds);

            }
            else
            {
                timerIsRunning = false;
                TimeUp();
            }
        }
    }

    public void StartTimer()
    {
        timerIsRunning = true;
    }

    public void StopTimer()
    {
        timerIsRunning = false;
    }

    public void TimeUp()
    {
        Debug.Log("Time's up!");
        Manager.instance.isGameOver = true;
        GameUI.instance.ShowLose();
    }
}
