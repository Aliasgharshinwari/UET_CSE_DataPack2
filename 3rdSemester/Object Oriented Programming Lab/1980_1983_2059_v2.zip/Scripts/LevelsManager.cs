using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelsManager : MonoBehaviour
{
    public GameObject player;
    private Vector3 playerPos;
    public static LevelsManager instance;
    public int currentLevel;
    public int totalLevels;
    public string[] levels;
    private const string INTERACTION_KEY = "HasInteracted";
    
    private void Awake() {
        instance = this;
    }
    private void Start()
    {
        currentLevel = PlayerPrefs.GetInt("CurrentLevel", 0);
        totalLevels = SceneManager.sceneCountInBuildSettings - 1;
        DontDestroyOnLoad(instance);
        playerPos.x = PlayerPrefs.GetFloat("PosX",0f);
        playerPos.y = PlayerPrefs.GetFloat("PosY",-11f);
        player.transform.SetPositionAndRotation(playerPos,Quaternion.identity);
         
         if (!PlayerPrefs.HasKey(INTERACTION_KEY))
        {
            PlayerPrefs.SetInt(INTERACTION_KEY, 1);
            MainMenuManager.instance.showWelcomeMenu();
        }
    }

    public void PlayLevel()
    {
        SceneManager.LoadScene(levels[currentLevel]);
    }

    public void UnclockNextLevel()
    {
        if (currentLevel < totalLevels)
        {
            currentLevel++;
            PlayerPrefs.SetInt("CurrentLevel", currentLevel);
        }
        else
        {
            Debug.Log("You have completed all levels!");
        }
    }
}
