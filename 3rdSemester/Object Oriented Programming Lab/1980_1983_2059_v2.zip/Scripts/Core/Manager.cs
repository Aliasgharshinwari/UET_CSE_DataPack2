﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Manager : MonoBehaviour
{

    public event System.Action<Chip> customChipCreated;
    public Chip[] builtinChips;
    ChipEditor activeChipEditor;
    int currentChipCreationIndex;
    public static Manager instance;
    public bool isGameOver = false;
    public bool[] correctOutputs = { false, false, false, false };
    public enum logicType
    {
        AND,
        NAND,
        OR,
        NOR,
        XOR
    }

    public logicType levelType;
    void Awake()
    {
        instance = this;
        activeChipEditor = FindObjectOfType<ChipEditor>();
    }


    public static ChipEditor ActiveChipEditor
    {
        get
        {
            return instance.activeChipEditor;
        }
    }
    public void SpawnChip(Chip chip)
    {
        activeChipEditor.chipInteraction.SpawnChip(chip);
    }

    public void LoadMainMenu()
    {
        SceneManager.LoadScene(0);
    }
    public void RestartSCene()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
    public void StartGame()
    {
        CountdownTimer.instance.StartTimer();
        GameUI.instance.hideWelcome();
    }

    public void testResult()
    {
        //foreach(ChipSignal s in activeChipEditor.inputsEditor.signals)
        //	Debug.Log(s.currentState);

        //foreach(ChipSignal s in activeChipEditor.outputsEditor.signals)
        //	Debug.Log(s.currentState);

        List<ChipSignal> inputSignals = activeChipEditor.inputsEditor.signals;
        List<ChipSignal> outputSignals = activeChipEditor.outputsEditor.signals;

        if (inputSignals.Count == 2 && outputSignals.Count == 1)
        {
            StartCoroutine(checkIO(inputSignals, outputSignals));
            Debug.Log("AND COROUTINE STARTED");
        }

        else
        {
            ModalWindow.instance.ShowModal("ERROR", "CHECK INPUTS AND OUTPUTS FIRST");
        }
    }

    public void checkFinalResult()
    {
        if (correctOutputs[0] && correctOutputs[1] &&
            correctOutputs[2] && correctOutputs[3])
        {
            GameUI.instance.ShowWin();
            CountdownTimer.instance.StopTimer();
            if (LevelsManager.instance)
                LevelsManager.instance.UnclockNextLevel();

            Debug.Log("YOU WON");
        }

        else
        {
            ModalWindow.instance.ShowModal("ERROR","ALL OUTPUTS ARE NOT CORRECT.\nPLEASE MAKE CORRECT CIRCUIT.");
            CountdownTimer.instance.StartTimer();
            Debug.Log("ALL OUTPUTS NOT CORRECT");
        }
    }

    IEnumerator checkIO(List<ChipSignal> iSignalsList, List<ChipSignal> oSignalsList)
    {
        CountdownTimer.instance.StopTimer();
        int s_no;
        for (int i = 0; i <= 1; i++)
        {
            for (int j = 0; j <= 1; j++)
            {
                s_no = System.Convert.ToInt32(i + "" + j, 2);
                ((InputSignal)iSignalsList[0]).SendSignal(i);
                ((InputSignal)iSignalsList[1]).SendSignal(j);

                yield return new WaitForSeconds(0.08f);

                if (levelType == logicType.AND)
                {
                    Debug.Log("AND");

                    if (((OutputSignal)oSignalsList[0]).currentState == (i & j))
                    {
                        correctOutputs[s_no] = true;
                        Debug.Log("Success");
                    }
                }

                if (levelType == logicType.NAND)
                {
                    Debug.Log("NAND");

                    if (((OutputSignal)oSignalsList[0]).currentState != (i & j))
                    {
                        Debug.Log( ~(i & j));
                        correctOutputs[s_no] = true;
                        Debug.Log("Success");
                    }
                }

                if (levelType == logicType.OR)
                {
                    Debug.Log("OR");

                    if (((OutputSignal)oSignalsList[0]).currentState == (i | j))
                    {
                        correctOutputs[s_no] = true;
                        Debug.Log("Success");
                    }
                } 

                if (levelType == logicType.NOR)
                {
                    Debug.Log("NOR");

                    if (((OutputSignal)oSignalsList[0]).currentState != (i | j))
                    {
                        correctOutputs[s_no] = true;
                        Debug.Log("Success");
                    }
                }
                
                if (levelType == logicType.XOR)
                {
                    Debug.Log("XOR");

                    if (((OutputSignal)oSignalsList[0]).currentState == (i ^ j))
                    {
                        correctOutputs[s_no] = true;
                        Debug.Log("Success");
                    }
                }               
            }
        }
        checkFinalResult();
    }
}