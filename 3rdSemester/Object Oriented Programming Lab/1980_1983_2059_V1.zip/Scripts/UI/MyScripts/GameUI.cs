using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;
public class GameUI : MonoBehaviour
{
    public static GameUI instance;
    public EndGameScreen winLosePanel;
    public GameObject welcomePanel;
    public ModalWindow modalWindow;
    public TMP_Text currentLevelTxt;
    Manager gm;

    private void Awake() {
        instance = this;
        
    }

    private void Start()
    {
        
        ShowWelcome();
        gm = Manager.instance;
        currentLevelTxt.text = "LEVEL: " + (SceneManager.GetActiveScene().buildIndex);
    }

    public void ShowWelcome()
    {
        welcomePanel.SetActive(true);
    }  
    
    public void hideWelcome()
    {
        welcomePanel.SetActive(false);
    }    
    public void ShowWin()
    {
        winLosePanel.ShowEndGameScreen("Congrats","You completed the task.");
        winLosePanel.restartLevelButton.gameObject.SetActive(false);
    }

    public void ShowLose()
    {
        winLosePanel.ShowEndGameScreen("TIME UP!!","\nYou Are No More with us\nSee you in Fall 2023!");
        winLosePanel.nextLevelButton.gameObject.SetActive(false);
    }

    public void SpawnAND(){
        gm.SpawnChip(gm.builtinChips[0]);
    }
    
    public void SpawnNOT(){
        gm.SpawnChip(gm.builtinChips[1]);
    }
    
    public void SpawnOR(){
        gm.SpawnChip(gm.builtinChips[2]);
    }
}
