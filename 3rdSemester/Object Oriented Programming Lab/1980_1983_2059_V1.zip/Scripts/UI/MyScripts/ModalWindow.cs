using UnityEngine;
using TMPro;
public class ModalWindow : MonoBehaviour
{
    public static ModalWindow instance;
    public GameObject modalWindow;
    public TMP_Text messageTitle;
    public TMP_Text messageText;

    private void Awake() {
        instance = this;
    }
    private void Start(){
        modalWindow.SetActive(false);
    }
    public void ShowModal(string title, string message){
        messageTitle.text = title;
        messageText.text = message;
        modalWindow.SetActive(true);
    }
    public void CloseModal(){
        modalWindow.SetActive(false);
    }
}
