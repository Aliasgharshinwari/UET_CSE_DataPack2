using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class EndGameScreen : MonoBehaviour
{
    public static EndGameScreen instance;
    public GameObject endGameWindow;
    public Button nextLevelButton;
    public Button restartLevelButton;
    public TMP_Text messageTitle;
    public TMP_Text messageText;

    private void Awake() {
        instance = this;
    }
    private void Start(){
        endGameWindow.SetActive(false);
    }

    public void ShowEndGameScreen(string title, string message){
        messageTitle.text = title;
        messageText.text = message;
        endGameWindow.SetActive(true);
    }

    public void CloseEndGameScreen(){
        endGameWindow.SetActive(false);
    }

    public void OnNextButtonClicked(){
        if (LevelsManager.instance)
            LevelsManager.instance.PlayLevel();
    }
}