﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuiltinChip : Chip {
	public Color packageColour;
}