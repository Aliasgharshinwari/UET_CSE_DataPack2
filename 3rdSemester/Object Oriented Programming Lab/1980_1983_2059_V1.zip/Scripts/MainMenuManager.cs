using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenuManager : MonoBehaviour
{
    public static MainMenuManager instance;
    public GameObject QuitMenu;
    public GameObject welcomeWindow;
    // Start is called before the first frame update
    void Awake()
    {
        instance = this;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
            showQuitMenu();
    }

    public void showQuitMenu(){
            QuitMenu.SetActive(true);
    }

    public void hideQuitMenu(){
            QuitMenu.SetActive(false);
    }

    public void showWelcomeMenu(){
        welcomeWindow.SetActive(true);
    }
    
    public void hideWelcomeMenu(){
        welcomeWindow.SetActive(false);
    } 

    public void exitGame(){
        Application.Quit();
    }       
}
